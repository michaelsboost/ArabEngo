// Application Name
var appName = "lessonMaker";
var langApp = "ArabEngo";
document.title = appName;

// Variables
var counter = 0,
    activeQuestion, heading,
    lessonName    = $(".apptitle").text();
    audioElement  = document.createElement("audio"),
    audioWord     = document.createElement("audio"),
    successSound  = function() {
      audioElement.setAttribute("src", "../../sounds/effects/success.mp3");
      audioElement.play();
    },
    errorSound    = function() {
      audioElement.setAttribute("src", "../../sounds/effects/error.mp3");
      audioElement.play();
    },
    wrongSound    = function() {
      audioElement.setAttribute("src", "../../sounds/effects/error.mp3");
      audioElement.play();
    },
    card          = function (word, source) {
      return '<a class="card pointer">\n        <h2>'+ word +'</h2>\n        \n        <img src="'+ source +'" height="125">\n      </a>'
    },
    heading             = '<title>ArabEngo: '+ lessonName +'</title>\n    <meta charset="utf-8">\n    <meta name="viewport" content="initial-scale=1.0">\n    <meta http-equiv="X-UA-Compatible" content="IE=9">\n    <link rel="stylesheet" href="../../css/style.css">\n    <script src="../../libraries/jquery/jquery.js"></script>\n    <script src="../../libraries/alertify/alertify.min.js"></script>',
    storeValues         = function() {
      // Remember Added lessonNotes
      if ( localStorage.getItem("lessonNotes")) {
        $("[data-edit=notes]").html(localStorage.getItem("lessonNotes"));

        $("[data-edit=notes]").on("keyup", function() {
          localStorage.setItem("lessonNotes", $("[data-edit=notes]").html());
          return false;
        });
      }
      // Remember Dictionary Notes
      if ( localStorage.getItem("dictionaryNotes")) {
        $("[data-code=dictionary]").val(localStorage.getItem("dictionaryNotes"));
      }
      // Remember Dictionary Notes
      if ( localStorage.getItem("skillName")) {
        lessonName = localStorage.getItem("skillName");
        $(".apptitle").text(lessonName);
        heading = '<title>ArabEngo: '+ lessonName +'</title>\n    <meta charset="utf-8">\n    <meta name="viewport" content="initial-scale=1.0">\n    <meta http-equiv="X-UA-Compatible" content="IE=9">\n    <link rel="stylesheet" href="../../css/style.css">\n    <script src="../../libraries/jquery/jquery.js"></script>\n    <script src="../../libraries/alertify/alertify.min.js"></script>';
      }
    },
    questionTypeChanged = function() {
      // Lesson name as page title
      s = lessonName.toString().toLowerCase();
      n = s.indexOf('-');
      s = s.substring(0, n != -1 ? n : s.length);
      skillPageDirect = s.replace("/\s/g");
      skillPageDirect = skillPageDirect.replace(" ", "").trim();

      $("[data-view=lesson] select").on("change", function() {
        // Value Options
        /*
          Which one of these is...
          How do you say...
          Translate this sentence
          Tap the pairs
          Select the missing word
          Question reply
          Translate the audio
          What was said?
          Match the audio
          Match picture with audio
          Speak the sentence
        */
        
        var tempContent = "Options for \"" + this.value + "\"<br><br> .designer-node:nth-child(" + activeQuestion + ")";
        // $("[data-view=lesson] [data-options=results]").html(tempContent);
        // $("[data-view=lesson] [data-options=answer]").html(tempContent);
        
        var jsTest = '<script src="../../js/responsivevoice.js"></script>\n    <script src="../../js/lessons.js"></script>\n    <script>\n      testSentence()\n    </script>';
        
        if ( this.value === "Which one of these is..." ) {
          // Append new data
          $("[data-view=lesson] [data-options=results]").empty()
          .append('<div style="text-align: center; font: 400 normal normal 24px/2 \'Lato\';">Which one of these is "<span style="text-decoration: underline;" data-find="card" class="questionTitle" contentEditable="true">woman</span>"?</div>')
          .append('<br>')
          .append('<div class="cards-container txtcenter" style="position: static; padding: 0; overflow: visible;">\n\n</div>');
          $("[data-view=lesson] [data-options=results] .cards-container").append(card("امراه", "image.svg") + card("رجل", "image.svg") + card("بنت", "image.svg") + card("ولد", "image.svg"));
          $("[data-view=lesson] [data-options=answer]").empty()
          .append('Answer/Text <u>must</u> be the same as what a card contains!')
          .append('<div style="font: 400 normal normal 24px/2 \'Lato\';" data-find="answer" contentEditable="true">امراه</div>')

          // Lesson name as page title
          lessonCode = '<a href="../../skills/'+ skillPageDirect +'.html" class="goback pointer"><i class="fa fa-times"></i></a><div class="cards-container txtcenter">'+ $("[data-view=lesson] .cards-container").html() +'</div><div class="object" style="position: absolute; top: 5px; left: 65px; right: 65px; text-align: center; font: 400 normal normal 24px/2 \'Lato\'; cursor: default;">Which one of these is "<span class="pointer underline eng speak">'+ $("[data-view=lesson] .questionTitle").text() +'</span>"?</div>';
          
          // Remove contentEditable for preview
          $("[data-view=lesson] [data-find]").on("keyup change", function() {
            if ( $("[data-find=card]").is(":focus") ) {
              console.log("Find card is active");
              lessonCode = '<a href="../../skills/'+ skillPageDirect +'.html" class="goback pointer"><i class="fa fa-times"></i></a><div class="cards-container txtcenter">'+ $("[data-view=lesson] .cards-container").html() +'</div><div class="object" style="position: absolute; top: 5px; left: 65px; right: 65px; text-align: center; font: 400 normal normal 24px/2 \'Lato\'; cursor: default;">Which one of these is "<span class="pointer underline eng speak">'+ $("[data-view=lesson] .questionTitle").text() +'</span>"?</div>';
            } else if ( $("[data-find=answer]").is(":focus") ) {
              console.log("Answer is active");
              lessonCode = '<a href="../../skills/'+ skillPageDirect +'.html" class="goback pointer"><i class="fa fa-times"></i></a><div class="cards-container txtcenter">'+ $("[data-view=lesson] .cards-container").html() +'</div><div class="object" style="position: absolute; top: 5px; left: 65px; right: 65px; text-align: center; font: 400 normal normal 24px/2 \'Lato\'; cursor: default;">Which one of these is "<span class="pointer underline eng speak">'+ $("[data-view=lesson] .questionTitle").text() +'</span>"?</div>';
            }
            updatePreview(heading + '<script src="../../js/responsivevoice.js"></script><script src="../../js/lessons.js"></script>' + lessonCode + '<scr'+'ipt>$(".cards-container").randomize(".card");$(".card").on("click", function() {\n  var pickedCard = $(this).find("h2").text();\n\n  if ( pickedCard === "'+ $("[data-find=answer]").text() +'" ) {\n    successSound();\n  } else {\n    errorSound();\n    this.style.backgroundColor = "#ff3666";\n  }\n});\n<'+'/scr'+'ipt>');
            $(".designer-node:nth-child("+ activeQuestion +")").next().html( $("[data-view=lesson]").html() ).trigger("change");
          }).trigger("change");
          
          // Change card name
          $("[data-view=lesson] .card h2").on("click", function() {
            $(this).addClass("cardTitle");
            alertify.prompt("Arabic name of card?",
              function(e, value) {
                if (e) {
                  $(".cardTitle").text(value)
                                 .removeAttr("class");
                  $("[data-view=lesson] [data-find=card]").trigger("change");
                  return false;
                } else {
                  // User clicked cancel
                  $(".cardTitle").removeAttr("class");
                  return false;
                }
              });
          });
          
          // Change card image source
          $("[data-view=lesson] .card img").on("click", function() {
            $(this).addClass("cardSrc");
            alertify.prompt("Paste image URL below!",
              function(e, value) {
                if (e) {
                  $(".cardSrc").attr("src", value)
                               .removeAttr("class");
                  $("[data-view=lesson] [data-find=card]").trigger("change");
                  return false;
                } else {
                  // User clicked cancel
                  $(".cardSrc").removeAttr("class");
                  return false;
                }
              });
          });

        } else if ( this.value === "How do you say..." ) {
          updatePreview(heading + tempContent);
          // updatePreview(heading + "&nbsp;" + jsTest);
        } else if ( this.value === "Translate this sentence" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Tap the pairs" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Select the missing word" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Question reply" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Question reply 'audio'" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Translate the audio" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "What was said?" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Match the audio" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Match picture with audio" ) {
          updatePreview(heading + tempContent);
        } else if ( this.value === "Speak the sentence" ) {
          updatePreview(heading + tempContent);
        } else {
          alertify.error("An error has been detected within the application. ", e);
        }
      });
    };

// LocalStorage
storeValues();

// Editor
var htmlEditor = CodeMirror.fromTextArea(document.getElementById("htmlEditor"), {
  mode: "text/html",
  tabMode: "indent",
  styleActiveLine: true,
  lineNumbers: true,
  lineWrapping: true,
  autoCloseTags: true,
  foldGutter: true,
  dragDrop: true,
  lint: true,
  gutters: ["CodeMirror-lint-markers", "CodeMirror-linenumbers", "CodeMirror-foldgutter"],
  paletteHints: true
});
Inlet(htmlEditor);
emmetCodeMirror(htmlEditor);
htmlEditor.on("change", function() {
  if ( $(".codenotes[data-view=notesCode]").is(":visible") ) {
    $("[data-edit=notes]").html( htmlEditor.getValue() );
    localStorage.setItem("lessonNotes", $("[data-edit=notes]").html());
  }
});

// Show/Write preview
function updatePreview(lessonCode) {
  $(".preview-editor").empty();
  var frame = document.createElement("iframe");
  frame.setAttribute("id", "preview");
  frame.setAttribute("class", "fill preview");
  frame.setAttribute("sandbox", "allow-forms allow-modals allow-pointer-lock allow-popups allow-same-origin allow-scripts");
  document.querySelector(".preview-editor").appendChild(frame);
  var previewFrame = document.getElementById("preview");
  var preview =  previewFrame.contentDocument ||  previewFrame.contentWindow.document;
  preview.open();
  preview.write(lessonCode);
  preview.close();
}

// Select a question
$(".designer-node").on("click", function() {
  activeQuestion = $(this).index() + 1;
  // Select by 0-2's
  
  if ( $(this).hasClass("active") ) {
    var whiteBG = "<style>\n  body {\n    background-color: #fff;\n  }\n</style>";
    $(".designer-node").removeClass("active");
    $("[data-view=lesson]").empty();
    updatePreview(whiteBG);
    return false;
  } else if ( $(".designer-node.active").is(":visible") ) {
    $(".designer-node").removeClass("active");
    $(this).addClass("active");
    $("[data-view=lesson]").html( $(this).next().html() );
    questionTypeChanged();
    $("[data-view=lesson] select").trigger("change");
    return false;
  } else {
    $(this).addClass("active");
    $("[data-view=lesson]").html( $(this).next().html() );
    questionTypeChanged();
    $("[data-view=lesson] select").trigger("change");
    return false;
  }
});
$(".designer-node:nth-child(3)").trigger("click");

// Clear all saved data
$("[data-clear=storage]").click(function() {
  alertify.confirm("<h2>Are you sure you want to start new?</h2> <h2 style='font-size: 17px;'>None of your changes will be saved!</h2>",
    function(e) {
      if (e) {
        localStorage.clear();
        location.reload(true);
      } else {
        // User clicked cancel
        return false;
      }
    });
});

// Save skill name
$(".apptitle").on("keyup change", function() {
  lessonName = this.textContent;
  localStorage.setItem("skillName", $(".apptitle").text());
});

// Notes
$(function() {
  $("[data-add=notes]").click(function() {
    // No editable elements
    $(this).toggleClass("active");
    $(".notes-container-fill").toggle();

    if ($(this).hasClass('active')) {
      if ( $(".codelessons[data-view=code]").is(":visible") ) {
        $("[data-view=code]").trigger("click");
      }
      if ( $(".active[data-add=dictionary]").is(":visible") ) {
        $("[data-add=dictionary]").trigger("click");
      }
      $(".hold-buttons button").not("[data-add=notes]").hide();
      $("[data-design=notes] button").css("display", "");
      $("[data-design=notes]").removeClass("hide");
      $("[data-edit=notes]").attr("contentEditable", "true");
      htmlEditor.setValue( $("[data-edit=notes]").html() );
      beautifyHTML(htmlEditor);
      htmlEditor.refresh();
    } else {
      $(".hold-buttons button").not("[data-add=notes], [data-design=lesson]").css("display", "");
      $("[data-design=notes] button").hide();
      $("[data-design=notes]").addClass("hide");
      $("[data-edit=notes]").removeAttr("contentEditable");
      if ( $("[data-view=notesCode]").hasClass("active") ) {
        $("[data-view=notesCode]").trigger("click");
      }
    }
  });
  $("[data-edit=notes]").on("keyup", function() {
    localStorage.setItem("lessonNotes", $("[data-edit=notes]").html());
    return false;
  });
  $("[data-view=notesCode]").click(function() {
    $(this).toggleClass("active");
    $(this).toggleClass("codenotes");
    $(".code-container-fill").toggle();

    htmlEditor.setValue( $("[data-edit=notes]").html() );
    beautifyHTML(htmlEditor);
  });
  // Undo
  $("[data-action=undo]").click(function() {
    document.execCommand("undo", false, true);
  });
  // Redo
  $("[data-action=redo]").click(function() {
    document.execCommand("redo", false, true);
  });
  // H1
  $("[data-action=h1]").click(function() {
    var value = window.getSelection();
    document.execCommand("insertHTML", true, "<h1 class=\"headline-primary--grouped txtcenter\">"+ value +"</h1>");
  });
  // H2
  $("[data-action=h2]").click(function() {
    var value = window.getSelection();
    document.execCommand("insertHTML", true, "<h2 class=\"headline-secondary--grouped modintoh2\">"+ value +"</h2>");
  });
  // Bold Head
  $("[data-action=boldhead]").click(function() {
    var value = window.getSelection();
    document.execCommand("insertHTML", true, "<b class=\"bold-heading\">"+ value +"</b>");
  });
  // Bold
  $("[data-action=bold]").click(function() {
    document.execCommand("bold", false, true);
  });
  // Paragraph
  $("[data-action=paragraph]").click(function() {
  //  document.execCommand("insertParagraph", false, true);
    var value = window.getSelection();
    document.execCommand("insertHTML", true, "<p>"+ value +"</p>");
  });
  // Italic
  $("[data-action=italic]").click(function() {
    document.execCommand("italic", false, true);
  });
  // Underline
  $("[data-action=underline]").click(function() {
    document.execCommand("underline", false, true);
  });
  // Strikethrough
  $("[data-action=strikethrough]").click(function() {
    document.execCommand("strikeThrough", false, true);
  });
  // Image
  $("[data-action=image]").click(function() {
    var imgSrc = prompt("Enter image location!", "");
    if (imgSrc != null) { 
      document.execCommand("insertImage", false, imgSrc);
    }
  });
  // Link
  $("[data-action=link]").click(function() {
    var linkURL = prompt("Enter the url for this link!", "http://");
    document.execCommand("createLink", false, linkURL);
  });
  // Unlink
  $("[data-action=unlink]").click(function() {
    document.execCommand("unlink", false, true);
  });
});

// Dictionary of skill words
$("[data-add=dictionary]").click(function() {
  // No editable elements
  $(this).toggleClass("active");
  $(".dictionary-container-fill").toggle();
});
$("[data-code=dictionary]").on("keyup", function() {
  localStorage.setItem("dictionaryNotes", $("[data-code=dictionary]").val());
});

// Download lesson
$("[data-download=lesson]").click(function() {
  /*
  // Get strings
  var fileName = $(".apptitle").text().replace(" ", "").toLowerCase();
  var notesCode = $("[data-edit=notes]").html().toString();
  var noteFull = '<!DOCTYPE html>\n<html>\n  <head>\n    <title>'+ langApp + ': '+ fileName +' Tips and Notes</title>\n    <meta charset="utf-8">\n    <meta name="viewport" content="initial-scale=1.0">\n    <meta http-equiv="X-UA-Compatible" content="IE=9" />\n    <link rel="stylesheet" href="../../css/style.css" />\n    <script src="../../libraries/jquery/jquery.js"></script>\n    <script src="../../libraries/alertify/alertify.min.js"></script>\n  </head>\n  <body>\n    <div class="underline-links">\n      <h4 id="type" class="grid">&nbsp;</h4>\n\n      <div class="breakword grid" style="background-color: #fefff6; box-shadow: 0 0 5px rgba(0, 0, 0, 0.2), inset 0 0 50px rgba(0, 0, 0, 0.1);">\n        <div class="centered grid__col--12" style="padding: 0 calc(100vw - 100%);">\n'+ notesCode +'        </div>\n      </div>\n      <p>&nbsp;</p>\n      <p>&nbsp;</p>\n    </div>\n\n    <a onclick="history.back()" class="goback pointer">\n      <i class="fa fa-chevron-left"></i>\n    </a>\n  </body>\n</html>';
  htmlEditor.setValue(noteFull);
  beautifyHTML(htmlEditor);
  noteFull = htmlEditor.getValue();
  
  var zip = new JSZip();
  var skills = zip.folder("skills");
  skills.file(fileName + ".html", "hello world");
  zip.file("lessons/" + fileName + "/index.html", "hello world");
  zip.file("lessons/" + fileName + "/notes.html", noteFull);
  zip.file("lessons/" + fileName + "/dictionary.txt", $("[data-code=dictionary]").val());
  var content = zip.generate({type:"blob"});
  saveAs(content, fileName + ".zip");
  */
  
  alertify.error("Sorry not yet ready to download lessons");
});

// Mousewhell for designer's horizontal scrollbar
(function() {
  function scrollDesign(e) {
    e = window.event || e;
    var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));
    document.getElementById('designscroll').scrollLeft -= (delta*40); // Multiplied by 40
    return false;
  }
  if (document.getElementById('designscroll').addEventListener) {
    // IE9, Chrome, Safari, Opera
    document.getElementById('designscroll').addEventListener('mousewheel', scrollDesign, false);
    // Firefox
    document.getElementById('designscroll').addEventListener('DOMMouseScroll', scrollDesign, false);
  } else {
    // IE 6/7/8
    document.getElementById('designscroll').attachEvent('onmousewheel', scrollDesign);
  }
  
  function scrollMenu(e) {
    e = window.event || e;
    var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));
    document.getElementById('notesmenu').scrollLeft -= (delta*40); // Multiplied by 40
    return false;
  }
  if (document.getElementById('notesmenu').addEventListener) {
    // IE9, Chrome, Safari, Opera
    document.getElementById('notesmenu').addEventListener('mousewheel', scrollMenu, false);
    // Firefox
    document.getElementById('notesmenu').addEventListener('DOMMouseScroll', scrollMenu, false);
  } else {
    // IE 6/7/8
    document.getElementById('notesmenu').attachEvent('onmousewheel', scrollMenu);
  }
})();